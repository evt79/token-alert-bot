def get_token_data():
    # Aquí conectarás con velo.xyz, dexu.ai, cryptobubbles
    # Retorna una lista simulada por ahora
    return [
        {'symbol': 'SOL', 'funding': 0.008, 'oi': 3800000000, 'narrative': 'AI'},
        {'symbol': 'PEPE', 'funding': 0.012, 'oi': 12000000, 'narrative': 'memecoin'},
        {'symbol': 'ETH', 'funding': 0.005, 'oi': 18500000000, 'narrative': 'DeFi'},
    ]
