# Token Alert Bot

Este bot analiza los mejores tokens cada hora según indicadores y te envía un email con el más prometedor.

## Despliegue en Render.com

1. Sube este código como nuevo repositorio a GitHub
2. Conéctalo a [https://render.com](https://render.com)
3. Selecciona **"Background Worker"**
4. Añade variables de entorno SMTP si no usas `config.py`
5. Empieza a recibir emails automáticos cada hora

✅ El archivo `config.py` contiene tus credenciales de Yahoo.

