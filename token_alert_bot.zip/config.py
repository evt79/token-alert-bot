config = {
    'email_sender': 'emiliantrupus@yahoo.es',
    'email_password': 'felicitus79',
    'smtp_server': 'smtp.mail.yahoo.com',
    'smtp_port': 465,
    'email_recipient': 'emiliantrupus@yahoo.es'
}
